# Phase 1 completion scope

1. Project packaging and source layout.
2. Read-only public kline retrieval from Binance Testnet endpoint.
3. EMA, RSI and a transparent sample signal.
4. Fixed-fractional position sizing and daily loss threshold helper.
5. Paper broker and unit tests.

Not included: authenticated account access, order execution, profit claims, persistent portfolio database, dashboard or automated scheduling.

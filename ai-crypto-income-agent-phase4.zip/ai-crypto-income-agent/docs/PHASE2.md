# Phase 2 — Historical Backtesting

Implemented a local, paper-only backtesting engine.

## Components
- `backtest.py`: candle model, long/flat simulation, fees, slippage, trade log, equity curve and metrics.
- `historical_data.py`: read-only public Binance Spot klines. It does not use account endpoints or API keys and filters the currently-forming candle.
- `backtest_cli.py`: downloads data and creates per-symbol JSON reports with chronological 70/30 training and out-of-sample evaluation.

## Default assumptions
- Starting capital: USD 100.
- Assets: BTCUSDT and ETHUSDT.
- Interval: 1 hour.
- EMA 50/200 and RSI 14.
- Allocation: 70% of available cash per entry; long/flat only.
- Fee: 0.10% per side.
- Slippage: 0.05% per side.
- Entry/exit: next candle open after a completed-candle signal.
- Test data receives a 200-candle warm-up, but trading is disabled during that warm-up.

## Metrics
Net profit, net return, win rate, maximum drawdown, annualized Sharpe ratio, number of completed trades, fees paid, equity curve and trade-level P&L.

The simulator is deliberately not an execution engine. No live orders, account credentials, margin, futures, leverage or withdrawals are implemented.

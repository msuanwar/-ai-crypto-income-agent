# Phase 4 — Read-only dashboard

- Phone-responsive Arabic RTL dashboard.
- Wallet equity, available cash, realized and unrealized PnL.
- Open positions and recent closed trades.
- Daily and weekly risk halt indicators.
- Public Binance ticker prices only; no signed/account/order endpoints.
- Refreshes every 15 seconds; manual refresh available.

Run: `crypto-dashboard --host 0.0.0.0 --port 8765`

The paper trader must be run separately. Dashboard is read-only and cannot execute orders.

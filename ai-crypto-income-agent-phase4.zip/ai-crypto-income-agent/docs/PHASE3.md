# Phase 3 — Continuous Paper Trading

Adds a persistent paper-only monitor for BTCUSDT and ETHUSDT. It reads public Spot candles, ignores any candle that has not closed, generates EMA/RSI signals, simulates long entries/exits, charges configurable-by-code simulated fees and slippage, tracks cash/equity and trade history, and writes a JSON state file plus JSONL cycle log.

## Run once

```bash
pip install -e ".[dev]"
crypto-paper --once
```

## Monitor continuously

```bash
crypto-paper --interval-seconds 300
```

Stop with Ctrl+C. The default state is `data/paper_state.json`; cycle logs are written to `reports/paper/cycles.jsonl`. Both paths are relative to the project root. Back up these files before deleting or resetting the simulation.

## Safety

This is a local simulation only. It uses public market candles and has no exchange account, API-key, order-placement, withdrawal, margin, futures, or leverage functionality. `allow_live_orders` must remain `false`. A paper result is not a promise of future income.

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .strategy import generate_signal


@dataclass
class Position:
    symbol: str
    quantity: float
    entry_price: float
    stop_price: float
    opened_at: str


@dataclass
class PaperState:
    cash: float = 100.0
    position: Position | None = None
    trades: list[dict[str, Any]] = field(default_factory=list)
    day_key: str = ""
    week_key: str = ""
    day_start_equity: float = 100.0
    week_start_equity: float = 100.0
    last_cycle: str = ""

    @classmethod
    def load(cls, path: Path, starting_balance: float) -> "PaperState":
        if not path.exists():
            return cls(cash=starting_balance, day_start_equity=starting_balance, week_start_equity=starting_balance)
        raw = json.loads(path.read_text(encoding="utf-8"))
        pos = Position(**raw["position"]) if raw.get("position") else None
        return cls(
            cash=float(raw["cash"]), position=pos, trades=raw.get("trades", []),
            day_key=raw.get("day_key", ""), week_key=raw.get("week_key", ""),
            day_start_equity=float(raw.get("day_start_equity", starting_balance)),
            week_start_equity=float(raw.get("week_start_equity", starting_balance)),
            last_cycle=raw.get("last_cycle", ""),
        )

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = asdict(self)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


class PaperTrader:
    """Long/flat simulator. It only consumes supplied public candle data."""
    def __init__(self, config: dict[str, Any], state: PaperState | None = None,
                 fee_pct: float = 0.001, slippage_pct: float = 0.0005):
        self.config = config
        self.state = state or PaperState(cash=float(config["starting_balance_usd"]))
        self.fee_pct = fee_pct
        self.slippage_pct = slippage_pct

    def equity(self, prices: dict[str, float]) -> float:
        pos = self.state.position
        return self.state.cash + (pos.quantity * prices.get(pos.symbol, pos.entry_price) if pos else 0.0)

    @staticmethod
    def _period_keys(now: datetime) -> tuple[str, str]:
        iso = now.isocalendar()
        return now.strftime("%Y-%m-%d"), f"{iso.year}-W{iso.week:02d}"

    def cycle(self, candles_by_symbol: dict[str, list[list]], now: datetime | None = None) -> dict[str, Any]:
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        now = now.astimezone(timezone.utc)
        # Use only completed candles. Binance kline close time is field 6.
        closed: dict[str, list[list]] = {}
        prices: dict[str, float] = {}
        signals: dict[str, str] = {}
        for symbol, candles in candles_by_symbol.items():
            rows = [c for c in candles if len(c) > 6 and int(c[6]) < int(now.timestamp() * 1000)]
            if not rows:
                continue
            closed[symbol] = rows
            prices[symbol] = float(rows[-1][4])
            closes = [float(c[4]) for c in rows]
            signals[symbol] = generate_signal(closes, int(self.config["fast_ema"]), int(self.config["slow_ema"]), int(self.config["rsi_period"]))

        equity = self.equity(prices)
        day_key, week_key = self._period_keys(now)
        if self.state.day_key != day_key:
            self.state.day_key, self.state.day_start_equity = day_key, equity
        if self.state.week_key != week_key:
            self.state.week_key, self.state.week_start_equity = week_key, equity
        daily_loss = max(0.0, (self.state.day_start_equity - equity) / max(self.state.day_start_equity, 1e-9) * 100)
        weekly_loss = max(0.0, (self.state.week_start_equity - equity) / max(self.state.week_start_equity, 1e-9) * 100)
        halted = daily_loss >= float(self.config["max_daily_loss_pct"]) or weekly_loss >= float(self.config["max_weekly_loss_pct"])
        action = "HOLD"
        pos = self.state.position

        if pos and pos.symbol in prices:
            price = prices[pos.symbol]
            if price <= pos.stop_price or signals.get(pos.symbol) == "EXIT_OR_STAY_FLAT":
                exit_price = price * (1 - self.slippage_pct)
                gross = pos.quantity * exit_price
                fee = gross * self.fee_pct
                self.state.cash += gross - fee
                pnl = (exit_price - pos.entry_price) * pos.quantity - fee - (pos.quantity * pos.entry_price * self.fee_pct)
                self.state.trades.append({"symbol": pos.symbol, "opened_at": pos.opened_at, "closed_at": now.isoformat(), "entry": pos.entry_price, "exit": exit_price, "quantity": pos.quantity, "pnl_usd": round(pnl, 8), "reason": "STOP_LOSS" if price <= pos.stop_price else "STRATEGY_EXIT"})
                self.state.position = None
                action = "SELL_SIMULATED"
                equity = self.equity(prices)

        if self.state.position is None and not halted:
            for symbol in self.config["symbols"]:
                if signals.get(symbol) != "BUY_CANDIDATE" or symbol not in prices or self.state.cash <= 1:
                    continue
                price = prices[symbol] * (1 + self.slippage_pct)
                # Risk-based notional using a conservative 2% stop, capped at 70% of cash.
                risk_budget = self.equity(prices) * (float(self.config["risk_per_trade_pct"]) / 100)
                risk_notional = risk_budget / 0.02
                notional = min(self.state.cash * 0.70, risk_notional)
                qty = notional / (price * (1 + self.fee_pct))
                cost = qty * price
                fee = cost * self.fee_pct
                if cost + fee > self.state.cash:
                    continue
                self.state.cash -= cost + fee
                self.state.position = Position(symbol, qty, price, price * 0.98, now.isoformat())
                action = "BUY_SIMULATED"
                break
        self.state.last_cycle = now.isoformat()
        equity = self.equity(prices)
        return {"timestamp": now.isoformat(), "mode": "PAPER_ONLY", "action": action,
                "signals": signals, "prices": prices, "cash_usd": round(self.state.cash, 4),
                "equity_usd": round(equity, 4), "position": asdict(self.state.position) if self.state.position else None,
                "daily_loss_pct": round(daily_loss, 4), "weekly_loss_pct": round(weekly_loss, 4),
                "risk_halted": halted, "closed_trades": len(self.state.trades)}

from __future__ import annotations

import json
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .backtest import Candle

BASE_URL = "https://api.binance.com"


def fetch_historical_klines(symbol: str, interval: str = "1h", limit: int = 1000, timeout: int = 20) -> list[Candle]:
    """Fetch public spot candles only; this module has no account/order endpoints."""
    allowed = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w"}
    if not symbol.isalnum() or interval not in allowed or not 1 <= limit <= 1000:
        raise ValueError("invalid symbol, interval or limit (1..1000)")
    query = urlencode({"symbol": symbol.upper(), "interval": interval, "limit": limit})
    request = Request(f"{BASE_URL}/api/v3/klines?{query}", headers={"User-Agent": "ai-crypto-income-agent/0.2"})
    with urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, list):
        raise RuntimeError(f"Binance public market-data error: {payload}")
    # Binance may include the currently-forming candle as the final row; omit it.
    now_ms = int(time.time() * 1000)
    closed = [row for row in payload if int(row[6]) < now_ms]
    return [Candle.from_binance(row) for row in closed]

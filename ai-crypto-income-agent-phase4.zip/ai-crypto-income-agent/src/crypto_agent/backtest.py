from __future__ import annotations

from dataclasses import asdict, dataclass
from math import sqrt
from statistics import mean, stdev
from typing import Sequence

from .indicators import ema, rsi


@dataclass(frozen=True)
class Candle:
    open_time: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    @classmethod
    def from_binance(cls, row: Sequence) -> "Candle":
        return cls(int(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5]))


@dataclass
class Trade:
    entry_time: int
    exit_time: int
    entry_price: float
    exit_price: float
    quantity: float
    pnl_usd: float
    return_pct: float


@dataclass
class BacktestResult:
    starting_balance: float
    ending_balance: float
    net_profit_usd: float
    net_profit_pct: float
    win_rate_pct: float
    max_drawdown_pct: float
    sharpe_ratio: float
    total_trades: int
    fees_paid_usd: float
    slippage_pct_per_side: float
    fee_pct_per_side: float
    equity_curve: list[float]
    trades: list[Trade]

    def to_dict(self) -> dict:
        result = asdict(self)
        return result


def run_backtest(
    candles: Sequence[Candle], *, starting_balance: float = 100.0,
    fast_period: int = 50, slow_period: int = 200, rsi_period: int = 14,
    allocation_pct: float = 70.0, fee_pct_per_side: float = 0.1,
    slippage_pct_per_side: float = 0.05, bars_per_year: int = 365 * 24,
    start_index: int | None = None,
) -> BacktestResult:
    """Long/flat close-confirmed backtest. Signals execute at the NEXT candle open."""
    if starting_balance <= 0 or not 0 < allocation_pct <= 100:
        raise ValueError("starting balance and allocation must be positive; allocation <= 100")
    if min(fast_period, slow_period, rsi_period, bars_per_year) <= 0 or fast_period >= slow_period:
        raise ValueError("invalid indicator periods or bars_per_year")
    if fee_pct_per_side < 0 or slippage_pct_per_side < 0:
        raise ValueError("fees and slippage cannot be negative")
    if len(candles) < slow_period + 3:
        raise ValueError(f"need at least {slow_period + 3} candles")
    for c in candles:
        if min(c.open, c.high, c.low, c.close) <= 0 or c.high < max(c.open, c.close) or c.low > min(c.open, c.close):
            raise ValueError("invalid OHLC candle")

    closes = [c.close for c in candles]
    fast = ema(closes, fast_period)
    slow = ema(closes, slow_period)
    momentum = rsi(closes, rsi_period)
    cash = starting_balance
    qty = 0.0
    entry_value = 0.0
    entry_price = 0.0
    entry_time = 0
    fees_paid = 0.0
    trades: list[Trade] = []
    curve: list[float] = []
    peak = starting_balance
    max_dd = 0.0

    def buy(c: Candle) -> None:
        nonlocal cash, qty, entry_value, entry_price, entry_time, fees_paid
        execution = c.open * (1 + slippage_pct_per_side / 100)
        spend = cash * allocation_pct / 100
        fee = spend * fee_pct_per_side / 100
        qty = (spend - fee) / execution
        cash -= spend
        fees_paid += fee
        entry_value = spend
        entry_price = execution
        entry_time = c.open_time

    def sell(c: Candle) -> None:
        nonlocal cash, qty, entry_value, fees_paid
        execution = c.open * (1 - slippage_pct_per_side / 100)
        gross = qty * execution
        fee = gross * fee_pct_per_side / 100
        net = gross - fee
        cash += net
        fees_paid += fee
        pnl = net - entry_value
        trades.append(Trade(entry_time, c.open_time, entry_price, execution, qty, pnl, (pnl / entry_value) * 100))
        qty = 0.0
        entry_value = 0.0

    # At candle i close, decide; execute at candle i+1 open (no look-ahead).
    evaluation_start = slow_period + 1 if start_index is None else start_index
    if evaluation_start < slow_period + 1 or evaluation_start >= len(candles) - 1:
        raise ValueError("start_index must leave enough warmup data and at least one execution candle")
    for i in range(evaluation_start, len(candles) - 1):
        signal = "HOLD"
        if momentum[i] is not None:
            if fast[i] > slow[i] and 50 <= momentum[i] <= 70:
                signal = "BUY"
            elif fast[i] < slow[i] or momentum[i] > 75:
                signal = "SELL"
        next_candle = candles[i + 1]
        if qty == 0 and signal == "BUY":
            buy(next_candle)
        elif qty > 0 and signal == "SELL":
            sell(next_candle)
        equity = cash + qty * candles[i].close
        curve.append(equity)
        peak = max(peak, equity)
        max_dd = max(max_dd, (peak - equity) / peak * 100)

    # Close any remaining position at the final candle close.
    last = candles[-1]
    if qty > 0:
        execution = last.close * (1 - slippage_pct_per_side / 100)
        gross = qty * execution
        fee = gross * fee_pct_per_side / 100
        net = gross - fee
        cash += net
        fees_paid += fee
        pnl = net - entry_value
        trades.append(Trade(entry_time, last.open_time, entry_price, execution, qty, pnl, pnl / entry_value * 100))
        qty = 0.0
    curve.append(cash)
    peak = max(peak, cash)
    max_dd = max(max_dd, (peak - cash) / peak * 100)

    returns = [(curve[i] / curve[i - 1]) - 1 for i in range(1, len(curve)) if curve[i - 1] > 0]
    sharpe = 0.0 if len(returns) < 2 or stdev(returns) == 0 else (mean(returns) / stdev(returns)) * sqrt(bars_per_year)
    wins = sum(t.pnl_usd > 0 for t in trades)
    ending = cash
    return BacktestResult(
        starting_balance, ending, ending - starting_balance,
        (ending / starting_balance - 1) * 100,
        wins / len(trades) * 100 if trades else 0.0,
        max_dd, sharpe, len(trades), fees_paid, slippage_pct_per_side,
        fee_pct_per_side, curve, trades,
    )

from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

from .market_data import BinancePublicClient
from .paper_trader import PaperState, PaperTrader


def main() -> None:
    parser = argparse.ArgumentParser(description="Paper-only crypto monitor; never places exchange orders")
    parser.add_argument("--once", action="store_true", help="run one monitoring cycle")
    parser.add_argument("--interval-seconds", type=int, default=300)
    parser.add_argument("--state", default="data/paper_state.json")
    parser.add_argument("--log", default="reports/paper/cycles.jsonl")
    args = parser.parse_args()
    if args.interval_seconds < 30:
        parser.error("interval-seconds must be at least 30")

    root = Path(__file__).resolve().parents[2]
    config = json.loads((root / "config" / "strategy.json").read_text(encoding="utf-8"))
    if config.get("mode") != "paper" or config.get("allow_live_orders") is not False:
        raise RuntimeError("Safety lock: paper mode only; live orders must remain disabled")
    state_path = root / args.state
    log_path = root / args.log
    state = PaperState.load(state_path, float(config["starting_balance_usd"]))
    trader = PaperTrader(config, state)
    client = BinancePublicClient(base_url="https://api.binance.com")

    while True:
        candles = {s: client.klines(s, config["interval"], 500) for s in config["symbols"]}
        result = trader.cycle(candles, datetime.now(timezone.utc))
        state.save(state_path)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(result) + "\n")
        print(json.dumps(result, indent=2))
        if args.once:
            break
        time.sleep(args.interval_seconds)


if __name__ == "__main__":
    main()

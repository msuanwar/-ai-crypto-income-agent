from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PaperBroker:
    cash: float = 100.0
    quantity: float = 0.0
    average_entry: float = 0.0

    def buy(self, price: float, quote_amount: float) -> float:
        if price <= 0 or quote_amount <= 0 or quote_amount > self.cash:
            raise ValueError("invalid price/amount or insufficient paper cash")
        qty = quote_amount / price
        total_cost = qty * price
        self.cash -= total_cost
        self.quantity += qty
        self.average_entry = price
        return qty

    def mark_to_market(self, price: float) -> float:
        if price <= 0:
            raise ValueError("price must be positive")
        return self.cash + self.quantity * price

from __future__ import annotations

from .indicators import ema, rsi


def generate_signal(closes: list[float], fast_period: int = 50, slow_period: int = 200, rsi_period: int = 14) -> str:
    """Conservative long/flat signal. Requires enough closed-candle observations."""
    if len(closes) < slow_period + 2:
        return "INSUFFICIENT_DATA"
    fast = ema(closes, fast_period)
    slow = ema(closes, slow_period)
    momentum = rsi(closes, rsi_period)
    if momentum[-1] is None:
        return "INSUFFICIENT_DATA"
    if fast[-1] > slow[-1] and 50 <= momentum[-1] <= 70:
        return "BUY_CANDIDATE"
    if fast[-1] < slow[-1] or momentum[-1] > 75:
        return "EXIT_OR_STAY_FLAT"
    return "HOLD_FLAT"

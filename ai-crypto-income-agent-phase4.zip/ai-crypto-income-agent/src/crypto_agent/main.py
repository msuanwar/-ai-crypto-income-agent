from __future__ import annotations

import json
from pathlib import Path

from .market_data import BinancePublicClient
from .strategy import generate_signal


def main() -> None:
    config_path = Path(__file__).resolve().parents[2] / "config" / "strategy.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config.get("mode") != "paper" or config.get("allow_live_orders") is not False:
        raise RuntimeError("Safety check failed: phase 1 must remain paper-only")
    client = BinancePublicClient()
    for symbol in config["symbols"]:
        candles = client.klines(symbol, config["interval"], 500)
        # Ignore the last candle because it may still be forming.
        closes = [float(candle[4]) for candle in candles[:-1]]
        signal = generate_signal(closes, config["fast_ema"], config["slow_ema"], config["rsi_period"])
        print(f"{symbol}: {signal} | candles={len(closes)} | mode=PAPER (no orders)")


if __name__ == "__main__":
    main()

"""AI Crypto Income Agent — paper-trading foundation."""
__version__ = "0.1.0"

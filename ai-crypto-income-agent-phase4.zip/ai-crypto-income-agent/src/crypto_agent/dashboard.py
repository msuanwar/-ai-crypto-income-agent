from __future__ import annotations
import json
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
ROOT = Path(__file__).resolve().parents[2]
DEFAULT_STATE = ROOT / 'data' / 'paper_state.json'
HTML = ROOT / 'dashboard' / 'index.html'

def public_price(symbol: str) -> float | None:
    """Read-only public ticker; no account or order endpoints."""
    try:
        req = Request(f'https://api.binance.com/api/v3/ticker/price?symbol={symbol}', headers={'User-Agent':'ai-crypto-agent-dashboard/1.0'})
        with urlopen(req, timeout=4) as response:
            return float(json.loads(response.read().decode())['price'])
    except Exception:
        return None

def build_dashboard_data(state_path: Path, symbols=None, price_reader=public_price) -> dict:
    symbols = symbols or ['BTCUSDT', 'ETHUSDT']
    raw = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {'cash':100.0,'positions':{},'trades':[],'halted_day':False,'halted_week':False}
    prices = {s: price_reader(s) for s in symbols}
    cash = float(raw.get('cash',100.0)); positions=[]; market_value=0.0
    for symbol,pos in raw.get('positions',{}).items():
        mark = prices.get(symbol) or float(pos['entry_price']); qty=float(pos['quantity'])
        value=qty*mark; market_value+=value
        positions.append({**pos,'symbol':symbol,'mark_price':mark,'market_value':value,'unrealized_pnl':(mark-float(pos['entry_price']))*qty})
    trades=list(reversed(raw.get('trades',[])))
    return {'mode':'PAPER ONLY','updated_at':datetime.now(timezone.utc).isoformat(),'cash_usd':cash,'market_value_usd':market_value,'equity_usd':cash+market_value,'realized_pnl_usd':sum(float(t.get('pnl_usd',0)) for t in raw.get('trades',[])),'unrealized_pnl_usd':sum(p['unrealized_pnl'] for p in positions),'open_positions':positions,'trades':trades[:50],'halted_day':bool(raw.get('halted_day',False)),'halted_week':bool(raw.get('halted_week',False)),'prices':prices,'has_state':state_path.exists()}

def make_handler(state_path: Path):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/api/state':
                payload=json.dumps(build_dashboard_data(state_path),ensure_ascii=False).encode()
                self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload); return
            if self.path in ('/','/index.html'):
                try: payload=HTML.read_bytes()
                except OSError: self.send_error(500,'Dashboard HTML is missing'); return
                self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload); return
            self.send_error(404)
        def log_message(self,*_args): pass
    return Handler

def main():
    import argparse
    parser=argparse.ArgumentParser(description='Read-only phone-friendly paper dashboard')
    parser.add_argument('--host',default='0.0.0.0'); parser.add_argument('--port',type=int,default=8765); parser.add_argument('--state',default=str(DEFAULT_STATE)); args=parser.parse_args()
    server=ThreadingHTTPServer((args.host,args.port),make_handler(Path(args.state)))
    print(f'Paper dashboard: http://127.0.0.1:{args.port} (LAN: http://YOUR-PC-IP:{args.port})')
    print('Read-only dashboard. No exchange orders are possible.')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
if __name__=='__main__': main()

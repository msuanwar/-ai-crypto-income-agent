from __future__ import annotations

import argparse
import json
from pathlib import Path

from .backtest import run_backtest
from .historical_data import fetch_historical_klines


def main() -> None:
    parser = argparse.ArgumentParser(description="Paper-only historical crypto backtest")
    parser.add_argument("--symbols", nargs="+", default=["BTCUSDT", "ETHUSDT"])
    parser.add_argument("--interval", default="1h")
    parser.add_argument("--limit", type=int, default=1000)
    parser.add_argument("--balance", type=float, default=100.0)
    parser.add_argument("--fee", type=float, default=0.1, help="fee percent per side")
    parser.add_argument("--slippage", type=float, default=0.05, help="slippage percent per side")
    parser.add_argument("--output", default="reports/backtest")
    args = parser.parse_args()
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    bars_per_year = {"1m": 365 * 24 * 60, "3m": 365 * 24 * 20, "5m": 365 * 24 * 12, "15m": 365 * 24 * 4, "30m": 365 * 24 * 2, "1h": 365 * 24, "2h": 365 * 12, "4h": 365 * 6, "6h": 365 * 4, "8h": 365 * 3, "12h": 365 * 2, "1d": 365, "3d": 365 / 3, "1w": 52}.get(args.interval, 365 * 24)
    for symbol in args.symbols:
        candles = fetch_historical_klines(symbol, args.interval, args.limit)
        if len(candles) < 290:
            print(f"{symbol}: not enough closed candles ({len(candles)}); skipped")
            continue
        split = int(len(candles) * 0.7)
        # Indicators warm up on the training segment; evaluate both segments separately.
        train = run_backtest(candles[:split], starting_balance=args.balance, fee_pct_per_side=args.fee, slippage_pct_per_side=args.slippage, bars_per_year=int(bars_per_year))
        test_data = candles[max(0, split - 200):]
        test = run_backtest(test_data, starting_balance=args.balance, fee_pct_per_side=args.fee, slippage_pct_per_side=args.slippage, bars_per_year=int(bars_per_year), start_index=200)
        report = {
            "symbol": symbol, "interval": args.interval, "candles": len(candles),
            "split": {"train_candles": split, "test_candles": len(candles) - split, "method": "chronological 70/30; test includes 200-candle indicator warmup"},
            "assumptions": {"starting_balance_usd": args.balance, "fee_pct_per_side": args.fee, "slippage_pct_per_side": args.slippage, "allocation_pct": 70, "execution": "next candle open after signal candle close", "mode": "simulation_only"},
            "training": train.to_dict(), "out_of_sample_test": test.to_dict(),
            "warning": "Historical simulation is not a profit guarantee. Results exclude taxes, spread variation and market impact beyond configured slippage."
        }
        path = out_dir / f"{symbol}_{args.interval}.json"
        path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"{symbol}: train {train.net_profit_pct:.2f}% | test {test.net_profit_pct:.2f}% | test max DD {test.max_drawdown_pct:.2f}% | trades {test.total_trades}; saved {path}")


if __name__ == "__main__":
    main()

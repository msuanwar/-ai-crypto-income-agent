from __future__ import annotations

import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class BinancePublicClient:
    """Read-only public klines client. This class has no order or account methods."""
    def __init__(self, base_url: str = "https://testnet.binance.vision", timeout: int = 15):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def klines(self, symbol: str, interval: str = "1h", limit: int = 500) -> list[list]:
        if not symbol.isalnum() or not 1 <= limit <= 1000:
            raise ValueError("invalid symbol or limit")
        query = urlencode({"symbol": symbol.upper(), "interval": interval, "limit": limit})
        req = Request(f"{self.base_url}/api/v3/klines?{query}", headers={"User-Agent": "crypto-agent/0.1"})
        with urlopen(req, timeout=self.timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if not isinstance(payload, list):
            raise RuntimeError(f"Unexpected Binance response: {payload}")
        return payload

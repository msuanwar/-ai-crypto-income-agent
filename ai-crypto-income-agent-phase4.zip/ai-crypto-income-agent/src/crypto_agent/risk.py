from __future__ import annotations


def position_size_usd(equity: float, entry: float, stop: float, risk_pct: float = 0.5) -> float:
    """Return notional position size using fixed fractional risk; never exceeds equity."""
    if equity <= 0 or entry <= 0 or stop <= 0:
        raise ValueError("equity, entry and stop must be positive")
    if not 0 < risk_pct <= 100:
        raise ValueError("risk_pct must be in (0, 100]")
    if stop >= entry:
        raise ValueError("for a long position, stop must be below entry")
    risk_dollars = equity * (risk_pct / 100)
    units = risk_dollars / (entry - stop)
    return min(units * entry, equity)


def daily_loss_limit_hit(start_of_day_equity: float, current_equity: float, limit_pct: float = 1.0) -> bool:
    if start_of_day_equity <= 0 or current_equity < 0 or not 0 < limit_pct <= 100:
        raise ValueError("invalid equity or limit")
    loss_pct = (start_of_day_equity - current_equity) / start_of_day_equity * 100
    return loss_pct >= limit_pct

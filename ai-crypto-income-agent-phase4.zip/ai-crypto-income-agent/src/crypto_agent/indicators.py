from __future__ import annotations

from typing import Iterable


def ema(values: Iterable[float], period: int) -> list[float]:
    data = list(values)
    if period <= 0:
        raise ValueError("period must be positive")
    if not data:
        return []
    alpha = 2 / (period + 1)
    result = [data[0]]
    for value in data[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result


def rsi(values: Iterable[float], period: int = 14) -> list[float | None]:
    data = list(values)
    if period <= 0:
        raise ValueError("period must be positive")
    if len(data) <= period:
        return [None] * len(data)
    gains = [max(data[i] - data[i - 1], 0.0) for i in range(1, len(data))]
    losses = [max(data[i - 1] - data[i], 0.0) for i in range(1, len(data))]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    out: list[float | None] = [None] * period

    def value(g: float, l: float) -> float:
        if l == 0:
            return 100.0 if g > 0 else 50.0
        rs = g / l
        return 100 - (100 / (1 + rs))

    out.append(value(avg_gain, avg_loss))
    for i in range(period, len(gains)):
        avg_gain = ((period - 1) * avg_gain + gains[i]) / period
        avg_loss = ((period - 1) * avg_loss + losses[i]) / period
        out.append(value(avg_gain, avg_loss))
    return out

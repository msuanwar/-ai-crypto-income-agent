# AI Crypto Income Agent — Phase 3 (Paper Trading)

Paper-only research and simulation project. It does **not** contain live order placement, account access, margin, futures, leverage, or withdrawal functionality.

## Current features
- Phase 1: EMA/RSI signal research, position sizing, paper broker and risk guards.
- Phase 2: public Binance Spot historical candles (market data only), closed-candle filtering, chronological 70/30 train/test split, next-candle-open execution, configurable trading fees and slippage, equity curve, net profit, win rate, maximum drawdown, Sharpe ratio, trade log and JSON reports.
- Default symbols: BTCUSDT and ETHUSDT; default starting balance: $100.

## Phase 3 — continuous paper trading
- Persistent simulated wallet for the $100 starting balance.
- Monitors BTCUSDT and ETHUSDT using completed public Spot candles only.
- Simulates long entries/exits, a 2% protective stop, fees/slippage, daily and weekly loss circuit breakers, and trade/cycle logs.
- No API keys or live orders.

Run one cycle with `crypto-paper --once`, or monitor every five minutes with `crypto-paper --interval-seconds 300`.

## Run
Python 3.11+ is required.

```bash
pip install -e ".[dev]"
pytest -q
crypto-backtest --symbols BTCUSDT ETHUSDT --interval 1h --limit 1000 --balance 100
```

Reports are written to `reports/backtest/`. If running without installing the package, use:

```bash
PYTHONPATH=src python -m crypto_agent.backtest_cli --symbols BTCUSDT ETHUSDT --interval 1h --limit 1000
```

## Backtest assumptions
- Signal uses only completed candle data; orders are simulated at the next candle open.
- Long/flat only, with 70% of available cash allocated per entry.
- Default fee is 0.10% per side and slippage is 0.05% per side; both are configurable.
- Test segment is chronological and begins after a 200-candle indicator warm-up. It is evaluated separately from the training segment.
- Sharpe is annualized using the selected interval (currently defaults to hourly annualization; adjust `bars_per_year` in code for other intervals).

Historical performance is not a guarantee of future results. This is not financial advice. Validate data quality and costs before drawing conclusions.

## Phase 4 — Read-only dashboard

Start the read-only dashboard with `crypto-dashboard --host 0.0.0.0 --port 8765`. Open `http://127.0.0.1:8765` on the same computer, or use the computer LAN IP and port 8765 from a phone on the same Wi-Fi. The dashboard refreshes every 15 seconds and displays wallet equity, cash, realized/unrealized PnL, public BTC/ETH prices, positions, closed trades, and risk guard status. It reads the paper-state JSON only and uses public ticker prices; it has no exchange account or order functionality.

Run the paper simulator separately using `crypto-paper --interval-seconds 60`. The dashboard does not start the simulator.

## Safety boundary
`allow_live_orders` remains `false`. No live exchange keys are needed or supported. Never add real order execution, margin, futures, leverage, or withdrawal permissions as part of these phases.

import pytest
from crypto_agent.risk import position_size_usd, daily_loss_limit_hit


def test_position_size_respects_risk_and_equity():
    size = position_size_usd(100, 100, 99, 0.5)
    assert size == pytest.approx(50.0)


def test_rejects_bad_stop():
    with pytest.raises(ValueError):
        position_size_usd(100, 100, 101)


def test_daily_loss_guard():
    assert daily_loss_limit_hit(100, 99, 1.0)
    assert not daily_loss_limit_hit(100, 99.5, 1.0)

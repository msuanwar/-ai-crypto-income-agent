import pytest
from crypto_agent.paper_broker import PaperBroker


def test_paper_buy_and_equity():
    broker = PaperBroker(cash=100)
    qty = broker.buy(10, 50)
    assert qty == 5
    assert broker.cash == 50
    assert broker.mark_to_market(12) == 110


def test_cannot_spend_more_than_cash():
    broker = PaperBroker(cash=10)
    with pytest.raises(ValueError):
        broker.buy(2, 11)

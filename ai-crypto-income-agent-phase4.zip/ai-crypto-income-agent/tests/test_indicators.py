from crypto_agent.indicators import ema, rsi


def test_ema_length_and_direction():
    result = ema([1, 2, 3, 4], 2)
    assert len(result) == 4
    assert result[-1] > result[0]


def test_rsi_uptrend_reaches_100():
    result = rsi(list(range(20)), 14)
    assert result[-1] == 100.0

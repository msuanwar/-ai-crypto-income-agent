import pytest

from crypto_agent.backtest import Candle, run_backtest


def make_candles(n=260):
    rows = []
    price = 100.0
    for i in range(n):
        # Deterministic trend with a later decline to exercise entry/exit paths.
        price *= 1.001 if i < 225 else 0.997
        rows.append(Candle(i * 3_600_000, price, price * 1.002, price * 0.998, price, 10.0))
    return rows


def test_backtest_produces_finite_metrics_and_respects_starting_balance():
    result = run_backtest(make_candles(), starting_balance=100.0)
    assert result.starting_balance == 100.0
    assert result.ending_balance > 0
    assert result.total_trades >= 0
    assert result.max_drawdown_pct >= 0
    assert result.fees_paid_usd >= 0
    assert len(result.equity_curve) > 0


def test_backtest_rejects_too_few_candles():
    with pytest.raises(ValueError):
        run_backtest(make_candles(100))


def test_backtest_rejects_negative_costs():
    with pytest.raises(ValueError):
        run_backtest(make_candles(), fee_pct_per_side=-0.1)


def test_backtest_rejects_invalid_start_index():
    with pytest.raises(ValueError):
        run_backtest(make_candles(), start_index=10)


def test_candle_from_binance_parses_ohlcv():
    candle = Candle.from_binance([1000, "10", "12", "9", "11", "50"])
    assert candle.open_time == 1000
    assert candle.close == 11
    assert candle.volume == 50

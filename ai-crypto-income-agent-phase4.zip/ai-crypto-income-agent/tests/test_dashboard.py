import json
from crypto_agent.dashboard import build_dashboard_data

def test_dashboard_empty_wallet(tmp_path):
    data=build_dashboard_data(tmp_path/'missing.json',price_reader=lambda _s:10.0)
    assert data['equity_usd']==100.0 and data['cash_usd']==100.0
    assert data['open_positions']==[] and data['mode']=='PAPER ONLY'

def test_dashboard_marks_positions_and_sums_pnl(tmp_path):
    p=tmp_path/'state.json'
    p.write_text(json.dumps({'cash':80,'positions':{'BTCUSDT':{'quantity':1,'entry_price':10,'stop_price':9,'entry_time':'x','entry_fee':0.1}},'trades':[{'pnl_usd':2}],'halted_day':False,'halted_week':True}))
    data=build_dashboard_data(p,['BTCUSDT'],price_reader=lambda _s:12.0)
    assert data['equity_usd']==92.0 and data['unrealized_pnl_usd']==2.0
    assert data['realized_pnl_usd']==2.0 and data['halted_week'] is True

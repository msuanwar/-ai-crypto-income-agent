from datetime import datetime, timezone

from crypto_agent.paper_trader import PaperState, PaperTrader


def cfg():
    return {"symbols": ["BTCUSDT", "ETHUSDT"], "fast_ema": 2, "slow_ema": 3,
            "rsi_period": 2, "starting_balance_usd": 100.0,
            "risk_per_trade_pct": 0.5, "max_daily_loss_pct": 1.0,
            "max_weekly_loss_pct": 3.0, "allow_live_orders": False, "mode": "paper"}


def candle(close, close_time=1_700_000_000_000):
    return [0, "0", "0", "0", str(close), "0", close_time]


def test_cycle_ignores_unclosed_candles(monkeypatch):
    import crypto_agent.paper_trader as module
    monkeypatch.setattr(module, "generate_signal", lambda *a: "HOLD_FLAT")
    trader = PaperTrader(cfg(), PaperState(cash=100))
    now = datetime.fromtimestamp(1_800_000_000, tz=timezone.utc)
    rows = [candle(100, int(now.timestamp() * 1000) - 1), candle(999, int(now.timestamp() * 1000) + 10000)]
    result = trader.cycle({"BTCUSDT": rows}, now)
    assert result["prices"]["BTCUSDT"] == 100
    assert result["mode"] == "PAPER_ONLY"
    assert result["action"] == "HOLD"


def test_buy_is_simulated_and_cash_is_preserved(monkeypatch):
    import crypto_agent.paper_trader as module
    monkeypatch.setattr(module, "generate_signal", lambda *a: "BUY_CANDIDATE")
    trader = PaperTrader(cfg(), PaperState(cash=100))
    now = datetime.fromtimestamp(1_800_000_000, tz=timezone.utc)
    rows = [candle(100, int(now.timestamp() * 1000) - 1)] * 210
    result = trader.cycle({"BTCUSDT": rows, "ETHUSDT": rows}, now)
    assert result["action"] == "BUY_SIMULATED"
    assert result["position"]["symbol"] == "BTCUSDT"
    assert 0 < result["cash_usd"] < 100
    assert result["mode"] == "PAPER_ONLY"


def test_state_round_trip(tmp_path):
    state = PaperState(cash=77.5)
    path = tmp_path / "state.json"
    state.save(path)
    loaded = PaperState.load(path, 100)
    assert loaded.cash == 77.5
    assert loaded.position is None

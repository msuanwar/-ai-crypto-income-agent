# Project instructions

- Preserve the paper-only safety boundary. Do not implement real order placement, account access, margin, futures, leverage, withdrawals or live API credentials.
- Use Python 3.11+, type hints, small modules and tests.
- Treat the final kline as potentially incomplete and exclude it from signals.
- Backtests must use completed candles and execute at the next candle open to avoid look-ahead bias.
- Always include fees, slippage, out-of-sample results and drawdown in backtest reporting.
- Never claim a strategy is profitable. Historical performance is not a profit guarantee.
- Keep secrets out of Git; `.env` is ignored.
- Run `pytest -q` after every change.
- Future phases may improve paper trading and monitoring, still without live orders.
